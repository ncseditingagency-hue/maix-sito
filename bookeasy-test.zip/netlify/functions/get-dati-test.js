// netlify/functions/get-dati-test.js
// SOLO PER TEST ISOLATO - usa una tabella separata invece di maix_users
// cosi possiamo provare BookEasy senza dipendere da login/account reali

const { createClient } = require('@supabase/supabase-js');
const supabase = createClient(process.env.SUPABASE_URL, process.env.SUPABASE_SERVICE_KEY);

exports.handler = async (event) => {
  const testId = event.queryStringParameters.auth_user_id;
  if (!testId) return { statusCode: 400, body: JSON.stringify({ error: 'id test mancante' }) };

  // Creiamo una riga finta in maix_users solo per questo test, se non esiste già
  let { data: utente } = await supabase.from('maix_users').select('*').eq('auth_user_id', testId).single();
  if (!utente) {
    const { data: nuovo, error } = await supabase.from('maix_users').insert({
      auth_user_id: testId,
      email: testId + '@test.bookeasy',
      settore: 'parrucchiere',
      formato_calendario: 'titolo+note',
    }).select().single();
    if (error) {
      return { statusCode: 500, body: JSON.stringify({ error: 'Impossibile creare utente di test: ' + error.message }) };
    }
    utente = nuovo;
  }

  const { data: eventi } = await supabase.from('eventi').select('*').eq('auth_user_id', testId).order('data_inizio', { ascending: false }).limit(10);
  const { data: chatRaw } = await supabase.from('chat_messaggi').select('*').eq('auth_user_id', testId).order('created_at', { ascending: false }).limit(40);
  const chat = (chatRaw || []).reverse();
  const { data: proposte } = await supabase.from('eventi_proposti').select('*').eq('auth_user_id', testId).eq('stato', 'in_attesa').order('created_at', { ascending: false }).limit(1);

  return {
    statusCode: 200,
    body: JSON.stringify({
      cliente: utente,
      eventi: eventi || [],
      chat: chat || [],
      propostaInAttesa: proposte && proposte.length ? proposte[0] : null,
    }),
  };
};
