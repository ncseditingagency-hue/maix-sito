// netlify/functions/oauth-start.js
const { google } = require('googleapis');

exports.handler = async (event) => {
  const authUserId = event.queryStringParameters.auth_user_id;

  const oauth2Client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.REDIRECT_URI
  );

  const url = oauth2Client.generateAuthUrl({
    access_type: 'offline',
    prompt: 'consent',
    scope: ['https://www.googleapis.com/auth/calendar.events'],
    state: authUserId,
  });

  return { statusCode: 302, headers: { Location: url }, body: '' };
};
